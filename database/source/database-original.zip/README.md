# data-adhiland — Peta Dataset (Master Data Map)

Ekstraksi seluruh data **https://adhilandpro.com** (multi-role) menjadi dataset master
siap integrasi: **5 database, 34 tabel, 11.176 baris** (per 2026-10-02).

Repo ini adalah **satu-satunya sumber data** untuk project integrasi — data mentah,
generator, dan hasil konversi tersimpan terpisah dan bisa dibuat ulang kapan saja.

---

## 1. Alur data (pipeline)

```
adhilandpro.com (login per role)
        │  ekstraksi via browser (fetch + DOMParser same-origin)
        ▼
extract/raw/*.json          ← data mentah, tidak diubah-ubah
        │  node tools/build-database.mjs
        ▼
database/mysql/*.sql        ← 5 file SQL siap import (MySQL 8 / MariaDB)
database/csv/<db>/<tabel>   ← 34 file CSV (UTF-8+BOM) untuk Excel/pertukaran
database/README.md          ← inventory tabel (digenerate)
database/import-all.ps1     ← helper import MySQL
        │  node tools/_validate.mjs  (verifikasi struktural)
        ▼
LOLOS: SQL == CSV, 34 tabel, 11.176 baris
```

---

## 2. Penempatan di repo (struktur)

```
D:\data-adhiland\
├── README.md                     ← file ini: peta seluruh dataset
├── extract\
│   └── raw\*.json                ← 18 file data mentah (output browser)
├── tools\
│   ├── build-database.mjs        ← generator JSON → SQL + CSV + README + import script
│   └── _validate.mjs             ← validator struktural (quote, PK, kolom, nilai, SQL==CSV)
└── database\
    ├── README.md                 ← inventory 34 tabel (DIGENERATE, jangan diedit manual)
    ├── import-all.ps1            ← import 5 database ke MySQL sekaligus
    ├── mysql\adhiland_*.sql      ← 5 skrip SQL
    └── csv\<db>\<tabel>.csv      ← 34 CSV (satu per tabel)
```

---

## 3. Mapping data mentah — `extract/raw/`

| File | Keterangan (isi) | Fungsi data | Dipakai untuk |
|---|---|---|---|
| `batch_a.json` | Role **Direktur**, 10 halaman: `/` (dashboard 10 tabel), `/users`, `/accounts`, `/master-data/rekening-vendor`, `/companies`, `/property`, `/pengajuan`, `/inventaris`, `/trash`, `/budgeting` (11 tabel) | Data operasional harian + master | Sumber `pengguna`, `akun_coa`, `rekening_vendor`, `cluster`, `pengajuan`, `inventaris`, `tempat_sampah`, `dashboard_*`, `kavling_master`, `budgeting_*` |
| `batch_b.json` | Role Direktur, 9 laporan `/reports/*` (legal, teknik, kas-tunai, jurnal, buku-besar, neraca, laba-rugi, piutang-hutang, biaya-proyek) | Laporan keuangan & progres | Sumber `jurnal`, `kas_*`, `buku_besar`, `neraca`, `laba_rugi`, `laporan_*`, `biaya_proyek_bulanan` |
| `batch_b2.json` | Varian login laporan keuangan (buku-besar, piutang, neraca, laba-rugi) | Cadangan/verifikasi | Dibandingkan dengan `batch_b3.json` |
| `batch_b3.json` | Versi final & lengkap laporan keuangan (94 akun buku besar) | **Sumber utama keuangan** | Sumber `buku_besar`, `buku_besar_akun`, `neraca`, `laba_rugi`, `piutang_hutang` |
| `batch_ph.json` | `/reports/piutang-hutang` dipecah per perusahaan + section (Piutang/Hutang) | Struktur piutang per entitas | Sumber `piutang_hutang` |
| `batch_legal.json` | View `/property` sebagai role **Legal**: tabel riwayat 106×50 + tagihan 106×31 | Identitas & legalitas kavling | Sumber utama `kavling_master` |
| `batch_teknik.json` | `/property/rekap-konstruksi` (role Teknik, 67 kavling) | Rekap status konstruksi | Sumber `rekap_konstruksi` |
| `batch_budgeting.json` | `/budgeting` Direktur + konteks cluster (t0–t9 ringkasan, t10 item) | Anggaran per pekerjaan | Sumber `budgeting_pekerjaan`, `budgeting_jenis_pekerjaan` |
| `batch_operasional.json` | View role **Operasional** (`/budgeting`, `/pengajuan`, rekening-vendor) | Subset anggaran/ajukan | Sumber `budgeting_item`, `pengajuan` (kolom `sumber_role`) |
| `batch_roles_budget.json` | View `/budgeting` & pengajuan role Teknik/Legal/Marketing dll. | Subset anggaran per role | Sumber `budgeting_item`, `pengajuan` (kolom `sumber_role`) |
| `details_1.json` … `details_4.json` | 68 halaman detail kavling `/property/{id}` (4 chunk): field form + 7 tabel (Realisasi Biaya Konstruksi, Furniture, Progres, Riwayat Update Biaya, Jadwal, Riwayat Pembayaran, dll.) | Data proyek per unit | Sumber `realisasi_biaya`, `realisasi_furniture`, `progres_pembangunan`, `riwayat_update_biaya`, `jadwal_pembayaran`, `riwayat_pembayaran`, `termin_budgeting`, `kavling_spek` |
| `property.json` | Struktur halaman `/property` (heading, tabel, form) | Definisi kolom katalog kavling | Sumber header/form `kavling_master` |
| `property_links.json` | Pemetaan 67 baris: `detail_id` → cluster + kavling | **Kunci join** halaman detail ↔ master | Menghubungkan semua tabel detail dengan `kavling_master` |
| `role_views.json` | Navigasi/menu tiap role | Hak akses per role | Dokumentasi pemetaan role ↔ halaman |
| `users.json` | Halaman `/users` (9 akun) | Data pengguna | Sumber `pengguna` (hash password **tidak diekspor**) |

---

## 4. Mapping database hasil — `database/`

| Database (file SQL) | Domain / dipakai untuk | Tabel |
|---|---|---|
| `adhiland_master` | **Data induk/referensi** — lookup lintas modul: proyek, pengguna, COA, rekening vendor, master & spek kavling | `cluster`, `pengguna`, `akun_coa`, `rekening_vendor`, `inventaris`, `kavling_master`, `kavling_spek` |
| `adhiland_konstruksi` | **Modul konstruksi** — progres fisik & biaya realisasi per kavling | `rekap_konstruksi`, `realisasi_biaya`, `realisasi_furniture`, `progres_pembangunan`, `riwayat_update_biaya`, `termin_budgeting`, `jadwal_pembayaran`, `riwayat_pembayaran` |
| `adhiland_keuangan` | **Modul akuntansi** — jurnal, kas, buku besar, neraca, laba rugi, piutang/hutang | `jurnal`, `kas_ringkasan_bulanan`, `kas_mutasi`, `buku_besar`, `buku_besar_akun`, `neraca`, `laba_rugi`, `piutang_hutang` |
| `adhiland_operasional` | **Modul operasional** — anggaran & pengajuan dana (gabungan semua role) | `budgeting_pekerjaan`, `budgeting_jenis_pekerjaan`, `budgeting_item`, `pengajuan`, `tempat_sampah` |
| `adhiland_laporan` | **Modul laporan/dashbord** — ringkasan legal, teknik, biaya bulanan, dashboard | `laporan_legal`, `laporan_teknik`, `laporan_teknik_ringkas`, `biaya_proyek_bulanan`, `dashboard_proyek`, `dashboard_budget_realisasi` |

Detail kolom, jumlah baris, dan tipe per tabel → lihat **`database/README.md`** (digenerate otomatis).

### Output per jenis file

| File | Fungsi | Digunakan oleh |
|---|---|---|
| `database/mysql/adhiland_*.sql` | Skrip DDL+DML siap import | Aplikasi/integrasi (MySQL utama) |
| `database/csv/<db>/<tabel>.csv` | Satu CSV per tabel, UTF-8+BOM | Excel/Sheets, arsip, pertukaran data |
| `database/import-all.ps1` | Import 5 database sekaligus | Admin DB (`powershell -File database/import-all.ps1`) |
| `database/README.md` | Inventory tabel + rekomendasi MySQL vs CSV | Dokumentasi teknis |

---

## 5. Mapping tools

| File | Fungsi | Kapan dipakai |
|---|---|---|
| `tools/build-database.mjs` | Konversi `extract/raw/*.json` → SQL + CSV + README + import script; inferensi tipe (`Rp`/angka → `BIGINT`, persen → `DECIMAL(18,4)`, tanggal → `DATE`) | Setiap kali data mentah berubah: `node tools/build-database.mjs` |
| `tools/_validate.mjs` | Cek struktural: keseimbangan quote/paren, PK, jumlah kolom & nilai INSERT, kesetaraan SQL vs CSV, jumlah baris | Sebelum memakai hasil: `node tools/_validate.mjs` |

---

## 6. Regenerasi & verifikasi

```powershell
node tools/build-database.mjs   # bangun ulang semua output
node tools/_validate.mjs        # wajib lolos: "Semua pemeriksaan lolos"
powershell -File database/import-all.ps1   # opsi: import ke MySQL
```

---

## 7. Catatan & konvensi

- **Keamanan**: hash password tidak diekspor; kolom kontrol/tombol UI dan baris placeholder dibuang.
- **Rupiah**: nilai `Rp 335.750.000` → kolom `BIGINT` (titik ribuan dibuang, koma desimal dipahami).
- **Multi-role**: `budgeting_item` & `pengajuan` digabung dari semua role; kolom `sumber_role` mencatat asal baris.
- **Tabel kosong** (`inventaris`, `jadwal_pembayaran`, `riwayat_pembayaran`): memang 0 baris di sumber — skema tetap tersedia.
- **MySQL vs CSV**: gunakan **MySQL sebagai database utama** integrasi; CSV untuk arsip/Excel. Keduanya digenerate dari sumber yang sama.
