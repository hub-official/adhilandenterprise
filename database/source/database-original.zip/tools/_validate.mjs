import fs from 'node:fs';
import path from 'node:path';

const ROOT = 'D:/data-adhiland/database';
let errors = 0;
const err = (m) => { errors++; console.log('  !! ' + m); };
const sqlCounts = {};
const csvCounts = {};

// --- SQL ---
const sqlDir = path.join(ROOT, 'mysql');
for (const f of fs.readdirSync(sqlDir).filter((x) => x.endsWith('.sql'))) {
  const txt = fs.readFileSync(path.join(sqlDir, f), 'utf8');
  console.log(`== ${f} ==`);
  // pisah statement di luar string
  const stmts = [];
  let cur = '', inStr = false, esc = false;
  for (let i = 0; i < txt.length; i++) {
    const c = txt[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === "'") inStr = false;
      cur += c;
      continue;
    }
    if (c === "'") { inStr = true; cur += c; continue; }
    if (c === ';') { stmts.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim()) stmts.push(cur.trim());
  if (inStr) err(`${f}: string tidak tertutup`);

  const tableCols = new Map();
  const inserted = new Map();
  for (const raw0 of stmts) {
    const s = raw0.replace(/(^|\n)\s*--[^\n]*/g, '').trim();
    if (!s) continue;
    let m;
    if ((m = s.match(/^CREATE TABLE `([^`]+)` \(([\s\S]*)\)\s*ENGINE/i))) {
      const body = m[2];
      // kolom = baris yang diawali backtick (di luar PRIMARY KEY)
      const cols = body.split('\n').map((l) => l.trim()).filter((l) => /^`/.test(l)).map((l) => l.match(/^`([^`]+)`/)[1]);
      const pk = (body.match(/PRIMARY KEY \(`([^`]+)`\)/) || [])[1];
      if (pk !== 'id') err(`${f}: primary key bukan id (${m[1]})`);
      if (tableCols.has(m[1])) err(`${f}: CREATE TABLE duplikat ${m[1]}`);
      tableCols.set(m[1], cols);
      let depth = 0, q = false, e = false;
      for (const ch of body) {
        if (q) { if (e) e = false; else if (ch === '\\') e = true; else if (ch === "'") q = false; continue; }
        if (ch === "'") q = true;
        else if (ch === '(') depth++;
        else if (ch === ')') depth--;
        if (depth < 0) break;
      }
      if (depth !== 0) err(`${f}: kurung CREATE TABLE ${m[1]} tidak seimbang (${depth})`);
    } else if ((m = s.match(/^INSERT INTO `([^`]+)` \(([\s\S]*?)\) VALUES([\s\S]*)$/))) {
      const tbl = m[1];
      const cols = m[2].split(',').map((x) => x.trim().replace(/`/g, ''));
      const declared = tableCols.get(tbl);
      if (!declared) { err(`${f}: INSERT ke tabel tak didefinisikan ${tbl}`); continue; }
      // id AUTO_INCREMENT tidak ikut INSERT
      const target = declared[0] === 'id' ? declared.slice(1) : declared;
      if (cols.length !== target.length) err(`${f}: ${tbl} INSERT ${cols.length} kolom vs CREATE ${target.length}`);
      cols.forEach((c, i) => { if (c !== target[i]) err(`${f}: ${tbl} kolom ke-${i} '${c}' != '${target[i]}'`); });
      // hitung tuple + cek jumlah nilai tuple pertama
      const body = m[3];
      let n = 0, depth = 0, q = false, e = false, start = -1, firstInner = null;
      for (let i = 0; i < body.length; i++) {
        const ch = body[i];
        if (q) { if (e) e = false; else if (ch === '\\') e = true; else if (ch === "'") q = false; continue; }
        if (ch === "'") { q = true; continue; }
        if (ch === '(') { if (depth === 0) start = i + 1; depth++; }
        else if (ch === ')') { depth--; if (depth === 0) { n++; if (firstInner === null) firstInner = body.slice(start, i); } }
      }
      if (depth !== 0 || q) err(`${f}: INSERT ${tbl} kurung/kutip tidak seimbang`);
      if (firstInner !== null) {
        let d = 0, qq = false, ee = false, items = 1;
        for (const ch of firstInner) {
          if (qq) { if (ee) ee = false; else if (ch === '\\') ee = true; else if (ch === "'") qq = false; continue; }
          if (ch === "'") qq = true;
          else if (ch === '(') d++;
          else if (ch === ')') d--;
          else if (ch === ',' && d === 0) items++;
        }
        if (items !== target.length) err(`${f}: ${tbl} tuple pertama punya ${items} nilai, harusnya ${target.length}`);
      } else if (target.length > 0) err(`${f}: INSERT ${tbl} tanpa baris`);
      inserted.set(tbl, (inserted.get(tbl) || 0) + n);
    } else if (/^(CREATE DATABASE|USE|--|$)/.test(s)) { /* ok */ }
    else err(`${f}: statement tak dikenal: ${s.slice(0, 70)}`);
  }
  console.log(`  ${stmts.filter(Boolean).length} statement, ${tableCols.size} tabel, ${[...inserted.values()].reduce((a, b) => a + b, 0)} baris`);
  sqlCounts[f.replace(/\.sql$/, '')] = inserted;
  for (const [t, c] of tableCols) {
    const n = inserted.get(t) || 0;
    if (n === 0) console.log(`  - ${t}: ${c.length} kolom, 0 baris`);
  }
}

// --- CSV ---
console.log('== CSV ==');
const csvRoot = path.join(ROOT, 'csv');
let csvFiles = 0, csvRows = 0;
for (const db of fs.readdirSync(csvRoot)) {
  for (const f of fs.readdirSync(path.join(csvRoot, db))) {
    const raw = fs.readFileSync(path.join(csvRoot, db, f), 'utf8');
    if (!raw.startsWith('\uFEFF')) err(`csv ${db}/${f}: tanpa BOM`);
    const body = raw.slice(1);
    // hitung baris ( RFC4180: baris di dalam "..." tidak dihitung )
    let nl = 0, q = false;
    for (let i = 0; i < body.length; i++) {
      const c = body[i];
      if (q) { if (c === '"') { if (body[i + 1] === '"') i++; else q = false; } continue; }
      if (c === '"') q = true;
      else if (c === '\n') nl++;
    }
    const lines = body.length && !body.endsWith('\n') ? nl + 1 : nl;
    const rows = Math.max(0, lines - 1);
    csvFiles++; csvRows += rows;
    (csvCounts[db] ||= {})[f.replace(/\.csv$/, '')] = rows;
    if (q) err(`csv ${db}/${f}: tanda kutip tidak seimbang`);
  }
}
console.log(`  ${csvFiles} file, ${csvRows} baris total`);

// --- SQL vs CSV harus identik ---
console.log('== SQL vs CSV ==');
let cmp = 0;
for (const db of Object.keys(sqlCounts)) {
  const tables = new Set([...sqlCounts[db].keys(), ...Object.keys(csvCounts[db] || {})]);
  for (const t of tables) {
    const a = sqlCounts[db].get(t) || 0;
    const b = (csvCounts[db] || {})[t];
    if (b === undefined) err(`tabel ${db}.${t} ada di SQL tapi tidak ada di CSV`);
    else if (a !== b) err(`${db}.${t}: SQL ${a} baris vs CSV ${b} baris`);
    cmp++;
  }
}
console.log(`  ${cmp} tabel dibandingkan`);
console.log(errors ? `\n${errors} ERROR` : '\nSemua pemeriksaan lolos.');
